package AccessModifiers;
import Pkg1.Profile;

public class FbProfile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Profile pf = new Profile();
    pf.setAge(10);
    System.out.println(pf.getAge());
    pf.setMaritalstatus("S");
    System.out.println(pf.getMaritalstatus());
    pf.setPhno(11111111);
    System.out.println(pf.getPhno());
    pf.setAge(20);
    System.out.println(pf.getAge());
    pf.setMaritalstatus("M");
    System.out.println(pf.getMaritalstatus());
    pf.setPhno(222222222);
    System.out.println(pf.getPhno());
	}
	

}
