package AccessModifiers;
import Pkg1.AgeDisp;
public class Accessmodifiers {
	public int age = 20;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Accessmodifiers am = new Accessmodifiers();
      AgeDisp ad = new AgeDisp();
      System.out.println(am.age);
      System.out.println(ad.age);
	}

}
