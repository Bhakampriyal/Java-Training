package Pkg1;

public class Circle extends Shape {
	int radius;
	Circle(int radius){
		this.radius = radius; 
	}
		public double calculateArea(){
		double area = 3.14*radius*radius;
		System.out.println("Area of Circle is: "+area);
		return area;
	}

}
