package Pkg1;

public class Squareshape extends Shape {
	int length,breadth;
	Squareshape(int length,int breadth){
		this.length=length;
		this.breadth=breadth;
	}
	public double calculateArea(){
		double area = length*breadth;
		System.out.println("Area of Square is: "+area);
		return area;
	}

}
