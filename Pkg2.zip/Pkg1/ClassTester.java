package Pkg1;

public class ClassTester {

	public static void main(String[] args) {
		C obja = (C)new B();
	//	C obj = new C();
	//	obja = (A) obj;
		obja.disp();
		obja.disp2();
		
	//	((C) obja).disp2();
		if (obja instanceof B) {
			System.out.println("obja instance of B");
		}
		if (obja instanceof C) {
			System.out.println("obja instance of C");
		}
		if (obja instanceof A) {
			System.out.println("obja instance of A");
		}
/*	obj.disp2();
	obj.disp();
	obj.disp1();
	((B) obj).disp1();
	obj.disp2();
	//C Object = new C();
	//((C) obj).disp2();*/

	}

}
