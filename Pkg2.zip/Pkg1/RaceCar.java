package Pkg1;

public class RaceCar implements IAdvVehicle {
	public void drive() {
		System.out.println("Method in IVehicle Interface is called");
	}

	public void accelerate() {
		System.out.println("Method in IAdvVehicle Interface is called");
	}

	public void race() {
		System.out.println("Method in Racecar class is called");
	}
}
