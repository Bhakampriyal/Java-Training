package Pkg1;

public class AgeDisp {
  public int age = 45;
  public String name = "Priya";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        AgeDisp ad = new AgeDisp();
        System.out.println(ad.age);
        System.out.println(ad.name);
	}

}
