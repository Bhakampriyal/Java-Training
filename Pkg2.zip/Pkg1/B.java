package Pkg1;

public class B extends A {
	void disp1() {
		System.out.println("Inside Class B");
	}

}
