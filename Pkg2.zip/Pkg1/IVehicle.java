package Pkg1;

public interface IVehicle {
	public void drive();

}
