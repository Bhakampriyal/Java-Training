package Pkg1;

public class Square {

	public  int length = 20;
	
	public static int calculateArea(int length) {
	// this.area = length * length;
	
	// this.length = length;
		
		return length;

	}
/*	 public void m1() {
		 System.out.println(length);
	 }
	
	 
	/*public int calculateArea(int length) {
	this.area = length * length;
	// area = length * length;
		return area;
}*/
	
	/*public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Square s = new Square(10);
		s.m1();
	//	 System.out.println(area);
	//   s.Square(10);
		

	}*/
}