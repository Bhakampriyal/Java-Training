package Pkg1;

public class bankMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       banksub s = new banksub();
       s.display();

	}

}
