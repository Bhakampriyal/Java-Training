package Pkg1;

public class ResultMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student stud = new Student();
		stud.setRno(10);
		stud.setStudname("Priya");
		stud.setM1(60);
		stud.setM2(40);
		stud.setM3(90);
		ResultCalc result = new ResultCalc();
		Result re = new Result();
		re= result.CalcResult(stud);
		System.out.println("Student Roll No:" +re.getRno() +","+"Student name:"+re.getStudname()+ " is " + re.getGrade()+" and secured a total " +re.getTotal());
		Student stud1 = new Student();
		stud1.setRno(11);
		stud1.setStudname("Rithu");
		stud1.setM1(80);
		stud1.setM2(70);
		stud1.setM3(90);
		re= result.CalcResult(stud1);
		System.out.println("Student Roll No:" +re.getRno() +","+"Student name:"+re.getStudname()+ " is " + re.getGrade()+" and secured a total " +re.getTotal());

	}

}
