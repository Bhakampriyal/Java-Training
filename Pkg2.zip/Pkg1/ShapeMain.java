package Pkg1;

public class ShapeMain {

	public static void main(String[] args) {
		Circle c = new Circle(20);
		c.setColor("Red","Circle");
		c.calculateArea();
		Squareshape s = new Squareshape(10, 10);
		s.setColor("Blue","Square");
		s.calculateArea();
	}

}
