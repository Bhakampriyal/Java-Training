package Pkg1;

public class C extends B {
	void disp2() {
		System.out.println("Inside Class C");
	}

}
