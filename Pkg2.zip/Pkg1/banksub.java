package Pkg1;

public class banksub extends bank {
	public int RI = 10;
	public void banki() {
       // RI = 10;
        System.out.println("Rate of Interest is : " +RI);
   
     

}
	 public void display() {
	 banksub bs = new banksub();
	 bs.banki();
	 super.banki();
	 System.out.println(bs.RI);
	 System.out.println(super.RI);
	 
}
}