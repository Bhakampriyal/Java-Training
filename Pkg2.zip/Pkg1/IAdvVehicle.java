package Pkg1;

public interface IAdvVehicle extends IVehicle{
	public void accelerate();
}
