package Pkg1;

public abstract class Shape {
	String color;
	String shape;
	public abstract double calculateArea();
    public void setColor(String c,String s) {
    	color = c;
    	shape = s;
    	System.out.println("Color of the " +shape +" shape is: " +color);
    }
    	
    }

