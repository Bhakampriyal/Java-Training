package Pkg1;

public class ResultCalc {

	public Result CalcResult(Student stud) {
		int total = stud.getM1() + stud.getM2() + stud.getM3();
		int average = total / 3;
		Result res = new Result();
		res.setTotal(total);
		res.setRno(stud.getRno());
		res.setStudname(stud.getStudname());
		if (average > 40) {
			res.setGrade("Pass");
		} else {
			res.setGrade("Fail");
		}
		return res;
	}
}
