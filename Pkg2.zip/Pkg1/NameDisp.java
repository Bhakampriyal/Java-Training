package Pkg1;

public class NameDisp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      AgeDisp af = new AgeDisp();
      System.out.println(af.name);
	}

}
