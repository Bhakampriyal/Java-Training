package Pkg1;

public class A {
	void disp() {
		System.out.println("Inside Class A");
	}

}
