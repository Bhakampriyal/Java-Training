package Pkg1;

public class RaceCarMain {

	public static void main(String[] args) {
		RaceCar rc = new RaceCar();
		rc.drive();
		rc.accelerate();
		rc.race();
	}

}
