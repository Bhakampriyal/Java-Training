package Pkg1;

public class bank {
	public int RI = 5;
	public void banki() {
       RI = 5;
        System.out.println("Rate of Interest is : " +RI);
	}
	
	

}
