package Pkg1;

public class SquareMain {
public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	//	Square s = new Square();
	//  System.out.println(s.calculateArea(10));
	System.out.println(Square.calculateArea(10));
		

	}

}
