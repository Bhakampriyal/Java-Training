package Pkg2;

public class Studentmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Student obj= new Student();
// obj.Id=1290;
obj.displayRegistrationId();
	}

}

