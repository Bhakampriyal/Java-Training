package Pkg2;

public class WelcomeMessage {
	public void displayMessage() {
	System.out.println("Welcome All");
	}

}
