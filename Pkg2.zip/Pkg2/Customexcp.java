package Pkg2;

public class Customexcp extends Exception {
	public void excep(String s) {
		System.out.println(s);
	}

}
