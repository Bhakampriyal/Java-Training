package Pkg2;

import java.util.*;
import java.util.List;

public class storeEvenMain {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<Integer>();
		StoreEvenNumber st = new StoreEvenNumber();
		list = st.storeEvenNumbers(20);
		System.out.println("Data in list A1 "+list);
		list = st.printEvenNumbers(5);
		System.out.println("Data in list A2 " +list);
		int x=st.retrieveEvenNumber(40);
		System.out.println(x);
	}

}
