package Pkg2;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class DateMain {

	public static void main(String[] args) throws ParseException {
		Date d = new Date();
		String d1="2018-41-02";
		DateFormat df = DateFormat.getDateInstance(DateFormat.LONG, Locale.ENGLISH);
		String formatdt = df.format(d);
		System.out.println(d);
		System.out.println(formatdt);
		String pattern = "F,EEEE, MMMMM dd, yyyy";
		String pattern1 = "yyyy-MM-dd";
		SimpleDateFormat simpleDateformat=new SimpleDateFormat(pattern1);
		Date date= simpleDateformat.parse("2018-12-02");
		System.out.println(date);
		String pattern2 = "EEEE,MMM,yy,dd";
		SimpleDateFormat sf = new SimpleDateFormat(pattern2);
		System.out.println(sf.format(date));
		int result = d.compareTo(date);
		System.out.println(result);
		

	}

}
