package Pkg2;

import java.util.*;

public class ArrayListMain {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<Integer>();
		int i;
	//	List list = new ArrayList();
		list.add(1);
		list.add(4);
		list.add(3);
		list.add(3);
		list.add(2);
	//	list.add(null);
	    System.out.println("Size of list is " + list.size());
		System.out.println("Data in list is " + list);
		list.set(3, 7);
		System.out.println("Size of list is " + list.size());
		System.out.println("Data in list is " + list);
		for (i=0;i<list.size();i++) {
			int a = list.get(i);
			System.out.println(a);
		}
		for(Integer b: list) {
			System.out.println(b);
		}
		Iterator itr = list.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		ArrayList1 ar1 = new ArrayList1();
		list = ar1.getList("A", "B", "C");
		System.out.println("Size of getlist is " + list.size());
		System.out.println("Data in getlist is " + list);
		list = ar1.returnList();
		System.out.println("Size of return list is " + list.size());
		System.out.println("Data in return list is " + list);
		list = ar1.getList2();
		System.out.println("Size of getlist2 is " + list.size());
		System.out.println("Data in getlist2 is " + list);
	}

}
