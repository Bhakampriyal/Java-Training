package Pkg2;

public class exception  {
	public void division(int a,int b) {
	try {
		int c = a/b;
		System.out.println(c);
	}
	catch(ArithmeticException d) {
		System.out.println(d);
	}
	System.out.println("Code executed");
	}
  /* public void result(int a,int b,int c) {
	   int d = a+b+c;
	   if (d < 40) {
		   try {
		   throw new Customexcp("Fail");
	   }
	   }
	   catch(Customexcp e) {
		   
	   }
	   System.out.println("Pass");
   }*/
}
