package Pkg2;

import java.util.*;

public class StoreEvenNumber {
	List <Integer> A1 = new ArrayList<Integer>();
	List <Integer> A2 = new ArrayList<Integer>();
	public List storeEvenNumbers(int n) {
		
		for(int i=2;i<=n;i++) {
			if (i%2 == 0) {
				A1.add(i);
			}
		}
		return A1;
	}
 public List printEvenNumbers(int n) {
	 for (int i=0;i<=n;i++) {
			int a = A1.get(i) * 2;
			A2.add(a);
		}
	 System.out.println(A2);
	 return A2;
 }
 public int retrieveEvenNumber(int n) {
	/* for (int i=0;i<A1.size();i++) {
			if (n == A1.get(i)) {
				return n;
			}
			}*/
	boolean b = A1.contains(n);
	 if (b==true) {
		 return n;
	 }
	// System.out.println(b);
	return 0;
	 
 }
}
