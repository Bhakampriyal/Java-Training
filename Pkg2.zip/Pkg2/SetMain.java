package Pkg2;

import java.util.*;

public class SetMain {

	public static void main(String[] args) {
		Set<String> fruits = new LinkedHashSet<String>();
		fruits.add("Apple");
		fruits.add(null);
		fruits.add("Orange");
		fruits.add("Apple");
		fruits.add("Grape");
		System.out.println("Size of fruit is " +fruits.size());
		System.out.println("Data in Fruits is " +fruits);
		Set<Integer> num = new HashSet<Integer>();
		num.add(2);
		num.add(1);
		num.add(5);
		num.add(1);
		num.add(null);
		System.out.println("Size of num is " +num.size());
		System.out.println("Data in num is " +num);
		Set<Integer> num1 = new TreeSet<Integer>();
		num1.add(2);
		num1.add(1);
		num1.add(5);
		num1.add(1);
	//	num1.add(null);
		for(int a: num1) {
			System.out.println(a);
		}
		Iterator itr = num1.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("Size of num is " +num1.size());
		System.out.println("Data in num is " +num1);
	}

}
