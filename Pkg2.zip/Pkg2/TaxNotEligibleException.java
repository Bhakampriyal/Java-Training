package Pkg2;

public class TaxNotEligibleException extends Exception{
	public TaxNotEligibleException(String msg) {
		super(msg);
	}

}
