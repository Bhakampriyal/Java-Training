package Pkg2;

public class exceptionMain {

	public static void main(String[] args) {
     exception e = new exception();
     e.division(10, 7);
     e.division(10, 0);
     e.division(0, 7);
     e.division(10, 5);
 //    e.result(10, 10, 10);
  //   e.result(40, 10, 10);
	}

}
