package Pkg2;

public class EmployeeNameInvalid extends Exception {
	public EmployeeNameInvalid(String msg){
		super(msg);
	}

}
