package Pkg2;

public class Calculator {
	int operand1,operand2,sum,diff,small,bAnd,bOr,bXor,bNot;
  /*  int operand2;
    int sum;
    int diff;
    int small;*/
    public void displayOperand() {
    	System.out.println("The value of operand1 is "+operand1);
    	System.out.println("The value of operand2 is "+operand2);
    	
    }
    public void addition(int operand1,int operand2) {
    	sum = operand1 + operand2;
    	System.out.println("The sum of " +operand1 +" and " +operand2 +" is :"+sum  );
    	
    }
    public void subtraction(int operand1,int operand2) {
    	diff = operand1 - operand2;
    	System.out.println("The difference of " +operand1 +" and " +operand2 +" is :"  +diff  );
    	
    }
    public void printSmaller(int operand1,int operand2) {
    	small=(operand1<operand2)?operand1:operand2;
    	System.out.println("The smallest number of " +operand1 +" and " +operand2 +" is :"  +small  );
    	
}
    public void bitwiseAnd(int operand1,int operand2) {
    	bAnd=operand1 & operand2;
    	System.out.println("The bitwise And of " +operand1 +" and " +operand2 +" is :"  +bAnd  );
    	
}
    public void bitwiseOr(int operand1,int operand2) {
    	bOr=operand1 | operand2;
    	System.out.println("The bitwise Or of " +operand1 +" and " +operand2 +" is :"  +bOr  );
    	
}
    public void bitwiseXor(int operand1,int operand2) {
    	bXor=operand1 ^ operand2;
    	System.out.println("The bitwise Xor of " +operand1 +" and " +operand2 +" is :"  +bXor  );
    	
}
    public void bitwiseNot(int operand1) {
    	bNot=~operand1;
    	System.out.println("The bitwise Not of " +operand1 +" is :"  +bNot  );
}
}
