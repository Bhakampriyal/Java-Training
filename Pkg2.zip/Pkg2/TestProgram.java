package Pkg2;

public class TestProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WelcomeMessage o1 = new WelcomeMessage();
		int i = 0;
	/*	while(i < 5) {
		o1.displayMessage();
		i++;
		}*/
		do {
			if(i !=3) {
			o1.displayMessage();
		     i++;
			}
			else {i++;
			continue ;
			  }
		}while (i < 5);
		System.out.println("Value of i is:"+i);
		
	}

}
