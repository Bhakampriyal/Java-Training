package Pkg2;

public class Casting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char a = '1';
		int b = a;
		int c = 1;
		char d = (char)c;
		int x;
		int y;
		int z;
		x=7;
		y=++x;
		z=x++;
		System.out.println("value of a is : " +a);
		System.out.println("value of b is : " +b); 
		System.out.println("value of c is : " +c);
		System.out.println("value of d is : " +d);
		System.out.println("value of y is : " +y);
		System.out.println("value of z is : " +z);
		
		
	}

}
