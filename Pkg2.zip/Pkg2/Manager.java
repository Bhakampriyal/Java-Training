package Pkg2;

public class Manager extends Employee{

	Manager(long id, String name, String address, long phone, double bsalary) {
		super(id, name, address, phone, bsalary);
	}
	public void calculateTransportAllowance() {
		double transportAllowance = 15 * basicSalary / 100;
	System.out.println("Transport Allowance of employee " +super.employeeName +" is " +transportAllowance);
}
}