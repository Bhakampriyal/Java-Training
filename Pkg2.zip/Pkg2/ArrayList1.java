package Pkg2;

import java.util.*;

public class ArrayList1 {
	List <Integer> intlist = new ArrayList();
	public List getList(String s1, String s2, String s3) {
		List strlist = new ArrayList();
		strlist.add(s1);
		strlist.add(s2);
		strlist.add(s3);
		return strlist;
	}
	public List <Integer> returnList(){
	//	List <Integer> intlist = new ArrayList();
		int i;
		for(i=1;i<=10;i++) {
			intlist.add(i);
		}
		return intlist;
		}
	public List<Integer> getList2(){
		List <Integer> intlist1 = new ArrayList<Integer>();
		int i;
		intlist1.addAll(intlist);
		for(i=11;i<=15;i++) {
			intlist1.add(i);
		}
		return intlist1;
	}
	}
	

