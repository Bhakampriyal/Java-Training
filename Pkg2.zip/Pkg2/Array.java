package Pkg2;

public class Array {
	int[] number=new int[11];
	public int[] storeNumber() {
		int i;
	//	int[] x=new int[11];
		for(i=0;i<=10;i++) {
			number[i]=i;
		}
		return number;
		}
	
   public void printEven() {
	   int i;
	   for(i=0;i<=10;i++) {
	   if (number[i]%2 == 0) {
		   System.out.println(number[i] +" is an even number");
	   }
	   }
   }
}

