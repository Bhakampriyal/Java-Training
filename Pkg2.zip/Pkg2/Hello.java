package Pkg2;

public class Hello {
	public void method() {
	    System.out.println("       By - Bhakampriyal");	
	}
	public String getname(String s)
	{
		System.out.println(s);
		return s;
		
	}
	public Hello() {
		System.out.println("   Inside Constructor ");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String name ="World";
		System.out.println("Hello "+name );
		Hello obj = new Hello();
		obj.getname("Bhakampriyal");
	}

}
