package Pkg2;

public class Student {
	/*public int Id = 0;*/
	public void displayRegistrationId() {
		 int Id;
		Id=1;
		System.out.println("The student registraion id is: "+Id);
	}

	
}
