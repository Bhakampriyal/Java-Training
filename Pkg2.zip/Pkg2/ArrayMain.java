package Pkg2;

public class ArrayMain {

	public static void main(String[] args) {
      Array ar = new Array();
      int i;
      int[] ans = ar.storeNumber();
      for (i=0;i<=10;i++) {
    	  System.out.println("Numbers stored in Array " +ans[i]);
      }
     ar.printEven();
	}

}
