package Pkg2;

public class Employee {
	long employeeId;
	String employeeName;
	String employeeAddress;
	long employeePhno;
	 double basicSalary;
	double specialAllowance = 250.00;
	double Hra = 1000.50;

	Employee(long id, String name, String address, long phone, double bsalary) {
		employeeId = id;
		employeeName = name;
		employeeAddress = address;
		employeePhno = phone;
		basicSalary = bsalary;
	}

	public void calculateSalary() {
		double salary = basicSalary + (basicSalary * specialAllowance / 100) + (basicSalary * Hra / 100);
		System.out.println("Calculated salary of employee " + employeeName + " is " + salary);
	}

	public void calculateTransportAllowance() {
		double transportAllowance = 10 * basicSalary / 100;
		System.out.println("Transport Allowance of employee " +employeeName +" is " +transportAllowance);

	}
}
