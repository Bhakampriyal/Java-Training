package Pkg2;

import java.io.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

public class IobuffersMain {

	public static void main(String[] args) {
		try {
			FileInputStream fin = new FileInputStream("D:\\abc.text");
			FileOutputStream fout = new FileOutputStream("D:\\def.text");
			/*
			 * String s = "Welcome to JPMC"; byte b[]=s.getBytes(); fout.write(b);
			 * fout.close(); System.out.println("Write Success");
			 */
			byte[] buffer = new byte[1024];
			int length = 0;
			File infile = new File("D:\\abc.text");
			File outfile = new File("D:\\def.text");
			BufferedReader br = new BufferedReader(new FileReader(infile));
		//	String st;
			while ((length=fin.read(buffer)) > 0) {
		//		System.out.println(st);
				fout.write(buffer,0,length);
			}
			fin.close();
			fout.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
