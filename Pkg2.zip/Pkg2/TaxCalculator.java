package Pkg2;

public class TaxCalculator {
	public double taxAmount;

	public double calculateTax(String empName, boolean isIndian, double empsal) throws EmployeeNameInvalid {

		if (!isIndian) {
			try {
				throw new CountryNotValidException("The Employee should be an Indian citizen for tax calculation");
			  
			} catch (CountryNotValidException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			}
		}
		if (empName == null) {
			//try {
				throw new EmployeeNameInvalid("Employee name cannot be empty");
			/*} catch (EmployeeNameInvalid e) {
				// TODO Auto-generated catch block
			System.out.println(e);

			}*/
		}

		if (empsal > 100000 && isIndian) {
			taxAmount = empsal * 8 / 100;
		} else if (empsal > 50000 && empsal < 100000 && isIndian) {
			taxAmount = empsal * 6 / 100;
		} else if (empsal > 30000 && empsal < 50000 && isIndian) {
			taxAmount = empsal * 5 / 100;
		} else if (empsal > 10000 && empsal < 30000 && isIndian) {
			taxAmount = empsal * 4 / 100;
		} else if (isIndian){
			try {
				throw new TaxNotEligibleException("Employee does'nt need to pay tax	");
			} catch (TaxNotEligibleException e) {
				System.out.println(e);
			}
		}
		return taxAmount;

	}

}
