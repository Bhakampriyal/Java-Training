package Pkg2;

public class Trainer extends Employee {

	Trainer(long id, String name, String address, long phone, double bsalary) {
		super(id, name, address, phone, bsalary);
	}
	public void calculateTransportAllowance() {
		super.calculateTransportAllowance();
	}
}
