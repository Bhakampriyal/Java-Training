package Pkg2;

public class CountryNotValidException extends Exception {

	public CountryNotValidException(String msg) {
		super(msg);
	}
}
