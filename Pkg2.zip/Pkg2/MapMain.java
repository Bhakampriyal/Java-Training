package Pkg2;

import java.util.*;

public class MapMain {

	public static void main(String[] args) {
		Map<Integer, Integer> m = new HashMap<Integer, Integer>();
		m.put(1, 10);
		m.put(5, 100);
		m.put(1, 20);
		m.put(3, 70);
		System.out.println(m);
		for(Map.Entry<Integer, Integer> x : m.entrySet()) {
			System.out.println("Key is "+x.getKey() + " Value is " +x.getValue());
		}

	}

}
