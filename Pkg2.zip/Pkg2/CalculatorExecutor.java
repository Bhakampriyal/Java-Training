package Pkg2;
import Pkg1.Square;
public class CalculatorExecutor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    /*    Calculator calc = new Calculator();
     calc.operand1 = 10;
      calc.operand2 = 20;
       calc.displayOperand();
        calc.addition(10, 20);
        calc.subtraction(10, 20);
        calc.printSmaller(30, 20);
        calc.bitwiseAnd(10, 20);
        calc.bitwiseOr(10, 20);
        calc.bitwiseXor(30, 20);
        calc.bitwiseNot(30);*/
        System.out.println(Square.calculateArea(20));
     
        
        
        
        
        
	}

}
