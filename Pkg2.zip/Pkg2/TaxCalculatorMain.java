package Pkg2;

public class TaxCalculatorMain {

	public static void main(String[] args) {
		TaxCalculator tc = new TaxCalculator();
		double tm=0;
		try {
			tm = tc.calculateTax(null, true, 55000);
		} catch (EmployeeNameInvalid e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(e);
		}
		if (tm != 0) {
			System.out.println("Tax Amount is:" + tc.taxAmount);
		}
	}

}
