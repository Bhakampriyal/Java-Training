var emp={
    "name": "bhakampriyal R",
    "Id": 232895,
    "Designation" : "Senior Developer"
}
console.log(emp);
console.log(JSON.stringify(emp))
var emp1={
    "name": "bhakampriyal R",
    "Id": 232895,
    "Designation" : "Senior Developer",
	"TechnologyKnown":["Mainframe","Java","C","C++","Database"]
}
console.log(emp1);
