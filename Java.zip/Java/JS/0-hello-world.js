console.log('----------hello world from js');
var s1 = 'abc';
    var s3= 'def';
    var name = 'praveen'
	var s4 = "hello" + name
	var s5 = `hello dear ${name}`;
 console.log(s5);
 