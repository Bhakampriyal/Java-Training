function validateForm(){
    let fn=document.getElementById("fn").value;
    let pwd=document.getElementById("pwd").value;
    let status=true;
    if(fn==null || fn=="" || fn==" "){
        document.getElementById("fn.err").innerHTML="Name required";
        status=false;
    }
    if(pwd==null || pwd=="" || pwd==" "){
        document.getElementById("pwd.err").innerHTML="Please enter Pwd";
        status=false;
    }
    
    return status;
}
function validatePwd(){
    location.href='./Setpwd.html';
}

function validateNPwd(){
    let npwd=document.getElementById("npwd").value;
    let cpwd=document.getElementById("cpwd").value;
    let status=true;
    if(npwd==null || npwd=="" || npwd==" "){
        document.getElementById("npwd.err").innerHTML="Please enter Pwd";
        status=false;
    }
    if(cpwd==null || cpwd=="" || cpwd==" "){
        document.getElementById("cpwd.err").innerHTML="Please confirm Pwd";
        status=false;
    }
    if(npwd.length !=8){
        document.getElementById("npwd.err").innerHTML="Please enter Pwd of length 8";
    }
    if(npwd != cpwd){
        document.getElementById("npwd.err").innerHTML="New password & confirm password are not same";
        status=false;
    }
    return status;
}